# Search Engine Front End Implementation

### Technologies Used

- CSS Grid
- Flexbox


> Made for the [Bottega Code School](https://bottega.tech)
